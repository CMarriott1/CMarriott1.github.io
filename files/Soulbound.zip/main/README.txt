The goal
========
Fight through rooms of enemies, discover items and travel through three floors of escalating difficulty until you reach the end!
Each new floor refills your health to prepare you for an increasing amount of rooms, enemies and overall difficulty.



Keybinds
========
Gameplay:
	WASD: Movement keys
	Arrow keys: Firing keys
	E: Map
	Q: Mini-boss summon

Selection Menus:
	Left/right keys: switch to previous/next upgrade/item
	Spacebar: Select Upgrade/Item



Enemies
=======
Red: Tries to hurt you by running towards you for as long as it's alive. Keep your distance.
Orange: Throws projectiles towards you to keep you on your toes. Dodge and weave between bullets.
Green: A big, slow, tanky enemy who, at first may appear slow, will occasionally charge towards you at full force. Keep track of when their charge is on cooldown



Stats
==============
One of these stats can be chosen to be upgraded between floors. There can only be two upgrades per run considering that there are three floor.

Attack: Damage dealt to enemies
Firerate: How often you can fire projectiles
Health: How much damage you can take per floor
Speed: How quickly you and your projectiles travel accross the screen


Items
=====
One of these will appear inside a single empty room per floor. These will significantly improve your damage per second in ways that are more interesting than just boosting your stats.

1: Your projectiles will pierce through enemies. Use careful planning to hurt multiple enemies in a row
2: You will shoot projectiles behind you in addition to your primary firing direction. You will find yourself surrounded less often
3: Your projectiles will warp to the other side of the screen, making your projectile remain active for a longer time. The projectile is gonna hit the second time, right? right???
4: Your projetiles will make enemies burst projectiles on death. Deal with hordes of enemies swiftly

This last item cannot be found in items rooms. This can only be found in a single unique circumstances where no other item can be spawned. This can be found without trying to break the game.
5: All stats up! All of your stats will be increased giving you a more well-rounded benefit that is less noticable compared to other items.

It's impossible to obtain two of the same item



Miniboss
========
Pressing the Q key will summon the mini-boss. This mini-boss looks like you and attempts to act like you too. I heard that the person controlling the mini-boss is the previous player but who knows.

When fighting, it will consider the horizontal and veritcal distance between them and you as well as considering your health, their health, your invulnerability frames, their invulnerability frames and the position of your projectiles.

Even though the mini-boss will be easier to defeat on later floors, it will also become harder to defeat on later floors too. Since this mini-boss tries to act like you, it also has an amount of reaction time but as you progress through floors, it will progressively get sharper reaction time. Knowing this, it's important to consider when to summon it.

As to why you should summon it, killing it will let you inherit one of the items it had by choice. If this is your first playthrough, it will have all the item that haven't been spawned yet. On future playthroughs however, it will have the same items as you did on the previous playthrough. What a weird coincidence. If all the items they have have been spawned previously, they will instead have a different item, item 5.



Cheat Codes
===========
Cheat codes can be entered only at the start of the game where "Press Enter to Start" is displayed. Only one can be chosen

These codes give the player small buffs if they're struggling

THATHURT: Damage incresae
SOYYMILK: Firerate decrease
CHEW5GUM: Speed increase
UABIGBOY: Increase in all stats (except health)

These codes give the player huge buffs if they want to feel overpowered

STRYMODE: Permanent invulnerability
ONEPUNCH: Kill all standard enemies with one projectile
2HARD4ME: Major increase in damage, Major decrease in firerate
URTOSLOW: Major increase in speed

These codes give the player huge debuffs if they feel the game needs to be impossibly difficult

HITHEGYM: Sets health to one
GLASCNON: Both you and standard enemies die in one hit
WEAKLING: Player projectiles deal one damage per shot (Normal damage is five)
2EASY4ME: Sets health and damage to one



